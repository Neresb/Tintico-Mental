# Tintico Mental — landing page

Sitio estático (HTML + imágenes), sin build.

- `index.html` — página de ventas
- `privacidad.html` — política de privacidad
- `terminos.html` — términos y condiciones
- `img/` — imágenes

## Publicar en Vercel
1. Importar este repositorio en vercel.com → New Project.
2. Framework Preset: **Other**. Build command: vacío. Output directory: `./`.
3. Deploy.

## Configuración
- Link del checkout y correo de soporte: bloque `CONFIG` al final de `index.html`.
- Píxel de Meta: pegar el código base donde está el comentario `META PIXEL` en el `<head>` de `index.html`.
